package com.example.myapplication

import android.os.Bundle
import androidx.leanback.app.RowsSupportFragment
import androidx.leanback.widget.*
import com.example.myapplication.network.ChenApi
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class MainFragment : RowsSupportFragment() {

    private lateinit var rowsAdapter: ArrayObjectAdapter
    private var previousVideoData: MutableList<ListRow> = mutableListOf()// 用于保存之前的视频数据

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        rowsAdapter = ArrayObjectAdapter(ListRowPresenter())
        adapter = rowsAdapter

        setupSearchRow()
        setupVideoRows()
    }

    private fun setupSearchRow() {
        val searchRowAdapter = ArrayObjectAdapter(SearchPresenter(this)) // 传入 MainFragment 的引用
        searchRowAdapter.add("搜索框")

        val headerItem = HeaderItem(0, "搜索")
        rowsAdapter.add(ListRow(headerItem, searchRowAdapter))
    }

    private fun setupVideoRows() {
        MainScope().launch {
            val chenApi = ChenApi()
            val v1: MutableList<Pair<String, String>> = mutableListOf()
            val v2: MutableList<Pair<String, String>> = mutableListOf()
            val v3: MutableList<Pair<String, String>> = mutableListOf()

            val m1 = chenApi.GetHotMovie(0)
            val m2 = chenApi.GetHotMovie(1)
            val m3 = chenApi.GetHotMovie(2)

            if (m1 != null) {
                for (i in m1.subjects) {
                    v1.add(Pair(i.title, i.cover))
                }
            }
            if (m2 != null) {
                for (i in m2.subjects) {
                    v2.add(Pair(i.title, i.cover))
                }
            }
            if (m3 != null) {
                for (i in m3.subjects) {
                    v3.add(Pair(i.title, i.cover))
                }
            }


            val videoRowAdapter = ArrayObjectAdapter(VideoCardPresenter())
            val videoRowAdapter2 = ArrayObjectAdapter(VideoCardPresenter())
            val videoRowAdapter3 = ArrayObjectAdapter(VideoCardPresenter())

            v1.forEach { videoRowAdapter.add(it) }
            v2.forEach { videoRowAdapter2.add(it) }
            v3.forEach { videoRowAdapter3.add(it) }

            val headerItem = HeaderItem(1, "电影")
            val headerItem2 = HeaderItem(2, "电视剧")
            val headerItem3 = HeaderItem(3, "动漫")
            rowsAdapter.add(ListRow(headerItem, videoRowAdapter))
            rowsAdapter.add(ListRow(headerItem2, videoRowAdapter2))
            rowsAdapter.add(ListRow(headerItem3, videoRowAdapter3))
            // 保存之前的视频数据
            previousVideoData.add(ListRow(headerItem, videoRowAdapter))
            previousVideoData.add(ListRow(headerItem2, videoRowAdapter2))
            previousVideoData.add(ListRow(headerItem3, videoRowAdapter3))
        }
    }

    fun updateVideoRows(videoData: List<Pair<String, String>>, isSear: Boolean) {
        val videoRowAdapter = ArrayObjectAdapter(VideoCardPresenter())

        // 清空当前的视频行并添加新的视频数据
        if (rowsAdapter.size() > 1) {
            rowsAdapter.removeItems(1, rowsAdapter.size() - 1)
        }

        if (isSear) {
            videoData.forEach { videoRowAdapter.add(it) }
            val headerItem = HeaderItem(1, "搜索结果")
            rowsAdapter.add(ListRow(headerItem, videoRowAdapter))
        } else {
            previousVideoData.forEach{ rowsAdapter.add(it) }
        }

    }
}
