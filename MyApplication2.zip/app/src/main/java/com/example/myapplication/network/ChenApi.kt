package com.example.myapplication.network

import com.example.myapplication.model.Douban
import com.example.myapplication.model.Resope
import com.example.myapplication.model.Sear
import com.example.myapplication.model.SearList
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json

class ChenApi {
    private val json = Json {
        ignoreUnknownKeys = true
    }
    val networkClient = OkHttp()
    //获取热门的影视 指定类型
    suspend fun GetHotMovie(index: Int): Douban? {
        val type = when (index) {
            0 -> "movie"
            1 -> "tv"
            2 -> "日本动画"
            else -> "movie"
        }


        val response = networkClient.get("http://47.107.50.50:9002/api/api/website/hot-movie/$type")

        return response?.let {
            try {
                var resope = json.decodeFromString<Resope>(it)
                json.decodeFromString<Douban>(resope.data)
            } catch (e: Exception) {
                println("JSON parsing error: ${e.message}")
                null
            }
        }
    }

    //获取搜索的影视
    suspend fun GetSear(name: String): List<Sear>? {
        val networkClient = OkHttp()
        val response = networkClient.get("http://110.41.14.10:8101/sear/${name}")
        return response?.let {
            try {
                json.decodeFromString<List<Sear>>(it)
            } catch (e: Exception) {
                println("JSON parsing error: ${e.message}")
                null
            }
        }
    }


}

