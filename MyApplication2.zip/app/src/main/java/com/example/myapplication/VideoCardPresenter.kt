package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.leanback.widget.Presenter
import com.bumptech.glide.Glide
import android.animation.ObjectAnimator
import android.graphics.Color

class VideoCardPresenter : Presenter() {

    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.video_card, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, item: Any) {
        val (title, imageUrl) = item as Pair<String, String>
        val videoImage = viewHolder.view.findViewById<ImageView>(R.id.videoImage)
        val videoTitle = viewHolder.view.findViewById<TextView>(R.id.videoTitle)

        videoTitle.text = title
        Glide.with(viewHolder.view.context).load(imageUrl).into(videoImage)

        viewHolder.view.setOnClickListener {
            Toast.makeText(viewHolder.view.context, "点击了: $title", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onUnbindViewHolder(viewHolder: ViewHolder) {
        // 清理资源
    }
}
