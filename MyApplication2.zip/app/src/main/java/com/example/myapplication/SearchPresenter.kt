package com.example.myapplication

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.leanback.widget.Presenter
import com.example.myapplication.network.ChenApi
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.launch

class SearchPresenter(private val fragment: MainFragment) : Presenter() {

    override fun onCreateViewHolder(parent: ViewGroup): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.search_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, item: Any) {
        val searchEditText = viewHolder.view.findViewById<EditText>(R.id.searchBox)
        val restButton = viewHolder.view.findViewById<TextView>(R.id.restButton)
        val searchButton = viewHolder.view.findViewById<TextView>(R.id.searchButton)
        val loadingSpinner = viewHolder.view.findViewById<ProgressBar>(R.id.loadingSpinner)

        // 确保按钮可获取焦点
        restButton.isFocusable = true
        restButton.isFocusableInTouchMode = true
        searchButton.isFocusable = true
        searchButton.isFocusableInTouchMode = true

        // 添加焦点变化监听器
        restButton.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                v.scaleX = 1.1f
                v.scaleY = 1.1f
                v.setBackgroundColor(Color.CYAN)
            } else {
                v.scaleX = 1f
                v.scaleY = 1f
                v.setBackgroundColor(Color.LTGRAY)
            }
        }
        searchButton.onFocusChangeListener = View.OnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                v.scaleX = 1.1f
                v.scaleY = 1.1f
                v.setBackgroundColor(Color.CYAN)
            } else {
                v.scaleX = 1f
                v.scaleY = 1f
                v.setBackgroundColor(Color.LTGRAY)
            }
        }

        // 添加失去焦点监听器到输入框
        searchEditText.setOnFocusChangeListener { v, hasFocus ->
            if (!hasFocus && searchEditText.text.isBlank()) {
                fragment.updateVideoRows(mutableListOf(), false)
            }
        }

        restButton.setOnClickListener {
            searchEditText.setText("")//清空输入框
            fragment.updateVideoRows(mutableListOf(), false)
        }

        // 设置点击事件
        searchButton.setOnClickListener {
            val query = searchEditText.text.toString()
            if (query != "") {
                Toast.makeText(viewHolder.view.context, "(*^▽^*)开始搜索: $query", Toast.LENGTH_SHORT).show()
                fragment.updateVideoRows(mutableListOf(), true)
                // 显示加载动画
                loadingSpinner.visibility = View.VISIBLE
                MainScope().launch {
                    val chenApi = ChenApi()
                    val v1: MutableList<Pair<String, String>> = mutableListOf()
                    val m1 = chenApi.GetSear(query)

                    // 隐藏加载动画
                    loadingSpinner.visibility = View.GONE

                    //此处得到了数据 然后更新视频列表
                    val vd: MutableList<Pair<String, String>> = mutableListOf()
                    if (m1 != null) {
                        for (i in m1) {
                            vd.add(Pair(i.title, i.cover))
                        }
                    }
                    // 调用 MainFragment 的更新方法
                    fragment.updateVideoRows(vd, true)
                    if (vd.count() > 0) {
                        Toast.makeText(
                            viewHolder.view.context,
                            "(*^▽^*) 搜索到了 ${vd.count()} 个结果！",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        Toast.makeText(viewHolder.view.context, "o(╥﹏╥)o 没有搜索到结果！", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                fragment.updateVideoRows(mutableListOf(), false)
            }
        }
    }
    override fun onUnbindViewHolder(viewHolder: ViewHolder) {
        // 清理资源
    }
}
